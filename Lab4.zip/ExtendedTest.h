#pragma once


void testAllExtended();