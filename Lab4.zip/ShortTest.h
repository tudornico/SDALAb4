#pragma once

void testAll();